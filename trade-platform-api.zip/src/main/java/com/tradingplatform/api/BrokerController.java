package com.tradingplatform.api;

import com.tradingplatform.common.ErrorMessages;
import com.tradingplatform.domain.BrokerAccount;
import com.tradingplatform.domain.User;
import com.tradingplatform.repository.BrokerAccountRepository;
import com.tradingplatform.repository.UserRepository;
import com.tradingplatform.service.AngelOneApiService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;
import java.util.Optional;

/**
 * Broker setup endpoints — each user connects their own broker account.
 *
 * POST   /api/broker/connect/angel-one  — save Angel One credentials
 * GET    /api/broker/my-account         — get current user's broker account
 * POST   /api/broker/test-connection    — test Angel One login
 * DELETE /api/broker/disconnect         — remove broker account
 */
@RestController
@RequestMapping("/api/broker")
public class BrokerController {

    private final BrokerAccountRepository brokerAccountRepository;
    private final UserRepository userRepository;
    private final AngelOneApiService angelOneApiService;

    public BrokerController(BrokerAccountRepository brokerAccountRepository,
                            UserRepository userRepository,
                            AngelOneApiService angelOneApiService) {
        this.brokerAccountRepository = brokerAccountRepository;
        this.userRepository = userRepository;
        this.angelOneApiService = angelOneApiService;
    }

    /** Connect Angel One — save encrypted credentials for the logged-in user */
    @PostMapping("/connect/angel-one")
    public ResponseEntity<?> connectAngelOne(@RequestBody ConnectRequest req,
                                              Authentication auth) {
        if (auth == null) return unauthorized();
        try {
            Long userId = (Long) auth.getDetails();
            User user = userRepository.getReferenceById(userId);

            // Check if already connected — update existing
            Optional<BrokerAccount> existing = brokerAccountRepository
                    .findByUserIdAndBrokerName(userId, "ANGEL_ONE");

            BrokerAccount account = existing.orElse(new BrokerAccount());
            account.setUser(user);
            account.setBrokerName("ANGEL_ONE");
            account.setClientCode(req.clientCode());
            account.setApiKey(req.apiKey());           // encrypted by JPA converter
            account.setPassword(req.password());       // encrypted by JPA converter
            account.setTotpSecret(req.totpSecret());   // encrypted by JPA converter
            account.setActive(true);
            if (account.getId() == null) {
                account.setCreatedAt(Instant.now());
            }
            account.setUpdatedAt(Instant.now());
            brokerAccountRepository.save(account);

            return ResponseEntity.ok(Map.of(
                    "message", "Angel One connected successfully",
                    "clientCode", req.clientCode()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", ErrorMessages.INTERNAL_ERROR));
        }
    }

    /** Get current user's connected broker account */
    @GetMapping("/my-account")
    public ResponseEntity<?> myAccount(Authentication auth) {
        if (auth == null) return unauthorized();
        Long userId = (Long) auth.getDetails();

        return brokerAccountRepository.findByUserIdAndBrokerName(userId, "ANGEL_ONE")
                .map(a -> ResponseEntity.ok(Map.of(
                        "id", a.getId(),
                        "brokerName", a.getBrokerName(),
                        "clientCode", a.getClientCode(),
                        "isActive", a.isActive(),
                        "createdAt", a.getCreatedAt().toString()
                )))
                .orElse(ResponseEntity.notFound().build());
    }

    /** Test Angel One connection by attempting login */
    @PostMapping("/test-connection")
    public ResponseEntity<?> testConnection(Authentication auth) {
        if (auth == null) return unauthorized();
        try {
            Long userId = (Long) auth.getDetails();
            BrokerAccount account = brokerAccountRepository
                    .findByUserIdAndBrokerName(userId, "ANGEL_ONE")
                    .orElseThrow(() -> new RuntimeException("No Angel One account connected"));

            // Attempt login using their credentials
            String result = angelOneApiService.login(account.getId());
            return ResponseEntity.ok(Map.of(
                    "message", "Connection successful",
                    "status", result
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Connection failed: " + e.getMessage()));
        }
    }

    /** Disconnect / remove broker account */
    @DeleteMapping("/disconnect")
    public ResponseEntity<?> disconnect(Authentication auth) {
        if (auth == null) return unauthorized();
        try {
            Long userId = (Long) auth.getDetails();
            brokerAccountRepository.findByUserIdAndBrokerName(userId, "ANGEL_ONE")
                    .ifPresent(brokerAccountRepository::delete);
            return ResponseEntity.ok(Map.of("message", "Broker disconnected"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", ErrorMessages.INTERNAL_ERROR));
        }
    }

    private ResponseEntity<?> unauthorized() {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", ErrorMessages.NOT_AUTHENTICATED));
    }

    public record ConnectRequest(
            @NotBlank String clientCode,
            @NotBlank String apiKey,
            @NotBlank String password,
            @NotBlank String totpSecret
    ) {}
}
